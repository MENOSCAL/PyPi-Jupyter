from setuptools import setup

setup(name='distributionsVM',
      version='0.2',
      description='Gaussian distributions',
      packages=['distributionsVM'],
      author = 'Victor Menoscal',
      author_email = 'alfonso_menos@hotmail.com',
      zip_safe=False)
